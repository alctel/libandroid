package com.vidyo.VidyoClientLib;

import com.vidyo.VidyoClient.entities.PortalEntity;

/*
 * This class will handle the passing of records across the JNI
 */
public class RecordHandler {
		public boolean processingUpdates = false;
		public PortalEntity[] entities = {};
		private PortalEntity[] processingEntities = null;
		
		private boolean lock = false;
		
		/*
		 * Number and range of records associated with this Query
		 */
		public int numPortalRecords = 0;
		public int startCacheIndex = -1;
		public int endCacheIndex = -1;
		public int maxCacheRecords = 0;
		public int numCacheRecords = 0;
		public int numMyRoomsRemoved = 0;
		
		/*public RecordHandler() {
		}*/
		
		public RecordHandler(PortalEntity[] setList) {
			entities = setList;
		}
		
		public boolean getLock() {
			if (lock) return false;
			lock = true;
			return true;
		}
		public void clearLock() {
			lock = false;
		}

		public void update(PortalEntity[] incoming) {
			entities = incoming;
		}
		
		public boolean update(PortalEntity[] incoming, boolean lastrec) {
			if (!lastrec) {
				if (processingUpdates) {
					processingEntities = PortalEntity.merge(processingEntities, incoming);
				} else {
					processingEntities = incoming;
					processingUpdates = true;
				}
			} else {
				if (processingUpdates) {
					entities = PortalEntity.merge(processingEntities,  incoming);
					processingUpdates = false;
				} else {
					entities = incoming;
				}
			}
			return processingUpdates;
		}
	}
	
