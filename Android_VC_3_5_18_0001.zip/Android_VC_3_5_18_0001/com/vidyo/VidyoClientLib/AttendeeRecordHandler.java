package com.vidyo.VidyoClientLib;

import com.vidyo.VidyoClient.entities.AttendeeEntity;

public class AttendeeRecordHandler {
	public boolean processingUpdates = false;
	public AttendeeEntity[] entities = {};
	private AttendeeEntity[] processingEntities = null;
	
	private boolean lock = false;
	
	public AttendeeRecordHandler(AttendeeEntity[] setList) {
		entities = setList;
	}
	
	public boolean getLock() {
		if (lock) return false;
		lock = true;
		return true;
	}
	public void clearLock() {
		lock = false;
	}

	public void update(AttendeeEntity[] incoming) {
		entities = incoming;
	}
	
	public boolean update(AttendeeEntity[] incoming, boolean lastrec) {
		if (!lastrec) {
			if (processingUpdates) {
				processingEntities = AttendeeEntity.merge(processingEntities, incoming);
			} else {
				processingEntities = incoming;
				processingUpdates = true;
			}
		} else {
			if (processingUpdates) {
				entities = AttendeeEntity.merge(processingEntities,  incoming);
				processingUpdates = false;
			} else {
				entities = incoming;
			}
		}
		return processingUpdates;
	}
}


